/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog.assignment.q1;

/**
 *
 * @author DISD3
 */
public class Q1 {
    
} 
public class Main {


	public static void main(String[] args) {


		System.out.println("BRIGHT FUTURE TECHNOLOGIES APPLICATION");
		System.out.println("*************************************************");
		System.out.println("Enter (1) to launch menu or any other key to exit");
		System.out.println("Please select one of following menu items:");
		System.out.println("(1) Capture a new product");
		System.out.println("(2) Search for a product");
		System.out.println("(3) Update a product");
		System.out.println("(4) Delete a product");
		System.out.println("(5) Print report");
		System.out.println("(6) Exit application");
	}


}
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner in =new Scanner(System.in);
	    String [] products=new String [5];
	    System.out.println("Capture & new Soduct");
	    
	    System.out.println("Enter the product code: ");
	    String p_code=in.next();
	    products[0]=p_code;
	    System.out.println("Enter the product nass: ");
	    String p_nass=in.next();
	    products[1]=p_nass;
	    System.out.println("Select product category: \\n1. Laptop \n2. Caming Const");
	    String p_category=in.next();
	    products[2]=p_category;
	    System.out.println("Enter the product warranty: ");
	    String p_warranty=in.next();
	    products[3]=p_warranty;
	    System.out.println("Enter the product price: ");
	    String p_price=in.next();
	    products[4]=p_price;
	    
	    System.out.println("Product code: "+p_code);
	    System.out.println("Product nass: "+p_nass);
	    System.out.println("Product category: "+p_category);
	    System.out.println("Product warranty: "+p_warranty);
	    System.out.println("Product price: "+p_price);
	    
	}
}

import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner in =new Scanner(System.in);
	    String [] products=new String [5];
	    System.out.println("Capture & new Soduct");
	    
	    System.out.println("Enter the product code: ");
	    String p_code=in.next();
	    products[0]=p_code;
	    System.out.println("Enter the product nass: ");
	    String p_nass=in.next();
	    products[1]=p_nass;
	    System.out.println("Select product category: \\n1. Laptop \n2. Caming Const");
	    String p_category=in.next();
	    products[2]=p_category;
	    System.out.println("Enter the product warranty: ");
	    String p_warranty=in.next();
	    products[3]=p_warranty;
	    System.out.println("Enter the product price: ");
	    String p_price=in.next();
	    products[4]=p_price;
	    
	    System.out.println("Product code: "+p_code);
	    System.out.println("Product nass: "+p_nass);
	    System.out.println("Product category: "+p_category);
	    System.out.println("Product warranty: "+p_warranty);
	    System.out.println("Product price: "+p_price);
	    
	}
}

import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner in =new Scanner(System.in);
	    System.out.println("Choose a category: \n1. Desktop Computer \n2. Laptop \n3. Tablet \n4. Printer\n5. Gaming Console");
	    int c;
	    c=in.nextInt();
	    if (c==1){
	        System.out.println("You have chosen Desktop Computer "); 
	    }
	    else if (c==2){
	        System.out.println("You have chosen Laptop");
	    }
	    else if (c==3){
	        System.out.println("You have chosen Tablet");
	    }
	    else if (c==4){
	        System.out.println("You have chosen Printer");
	    }
	    else if (c==5){
	        System.out.println("You have chosen game console");
	    }
	    else{
	        System.out.println("Enter a valid product category");
	    }
	    
	    int c2;
	    System.out.println("Choose warranty:\n1. Applies a six-month product warranty\n2. Any other key applies a two-year warranty");
	
	    c2=in.nextInt();
	    System.out.println("Product details have been successfully saved");
	}
}

import java.util.Scanner;
public class Main
{
    public static void Search(int[] arr, int k){    
        for(int i=0;i<arr.length;i++){    
            if(arr[i] == k){    
                System.out.println("The product is found.");
                break;
            }    
        }    
        System.out.println("The product is not found.");    
    }   
	public static void main(String[] args) {
	    Scanner in=new Scanner(System.in);
		int[] arr= {121,122,123,124,125,126,127};  
		System.out.println("Enter the product code to search:");
		int product_code=in.nextInt();
		
		Search(arr,product_code);
		
	}
}

import java.util.Scanner;


public class Main 
{
  
public static int Search (int[]arr, int k)
  {
    
for (int i = 0; i < arr.length; i++)
      {
	
if (arr[i] == k)
	  {
	    
return i;
	  
}
      
}
    
System.out.println ("The product is not found.");
    
return -1;
  
}
  
public static void main (String[]args)
  {
    
Scanner in = new Scanner (System.in);
    
System.out.println ("Enter number of products: ");
    
int n = in.nextInt ();
    
Product[]p = new Product[n];
    
 
for (int i = 0; i < n; i++)
      {
	
p[i].getpcode ();
	
p[i].getpcategory ();
	
p[i].getpwarranty ();


p[i].getpprice ();
    
 
} 
for (int i = 0; i < n; i++)
      {
	
p[i].display ();
      
} 
int[] arr = new int[n];
    
 
for (int i = 0; i < n; i++)
      {
	
arr[i] = p[i].getpcode ();
      
} 
 
int pcd;
    
System.out.println ("Enter the product code for the product to delete:");
    
pcd = in.nextInt ();
    
 
int n2 = Search (arr, pcd);
    
arr[0] = 0;
    
 
System.out.println ("Please enter the product code to update: ");
    
int pcd2 = in.nextInt();
    
System.out.println ("Update the warranty? (y) Yes, (n) No (n)");
    
String a1 = in.next();
    
System.out.println ("Update the product price? (y) Yes, (n) No ");
    
String a2 = in.next();
	
System.out.println("Enter the new price for EliteBook");
double a3=in.nextDouble();
	
System.out.println("Update the stock level? (y) Yes, (n) No n ");
String a4=in.next();


System.out.println("Product details has been updated successfully!!!");
 
} 
} 
 
 
 
 
class Product


{
  
private int p_code;
  
private String p_category;
  
private String p_warranty;
  
private double p_price;
  
Scanner in = new Scanner (System.in);
  
public int getpcode ()
  {
    
System.out.println ("Enter the product code: ");
    
p_code = in.nextInt ();
    
return p_code;
  
}
  
 
public void getpcategory ()
  {
    
System.out.println ("Enter product category: ");
    
p_category = in.next ();
  
} 
 
public void getpwarranty ()
  {
    
System.out.println ("Enter the product warranty: ");
    
p_warranty = in.next ();
  
} 
public void getpprice ()
  {
    
System.out.println ("Enter the product price: ");
    
p_price = in.nextDouble ();
  
} 
public void display ()
  {
    
System.out.println ("Product code: " + p_code);
    
System.out.println ("Product category: " + p_category);
    
System.out.println ("Product warranty: " + p_warranty);
    
System.out.println ("Product price: " + p_price);


} 
}

import java.util.Scanner;
 class ReportData {
     // private = restricted access
    private String book_name;
    private String book_author;
     private String copies_available;
     private String copies_sold;
     //private int num_of_products;

     // Setters
     public void setbook_name(String b_name) {
         this.book_name = b_name;
     }
     public void set_author(String ar_name) {
         this.book_author = ar_name;
     }
     public void setCopies_available(String cpa_code) {
         this.copies_available = cpa_code;
     }
     public void setCopies_sold(String cps_code) {
         this.copies_sold = cps_code;
     }
     // Getters
    public String getBook_name_name() {
        return book_name;
    }
     public String getBook_author() {
         return book_author;
     }
     public String getCopies_available() {
         return copies_available;
     }
     public String getCopies_sold() {
         return copies_sold;
     }
     //Method for printing the details of the products
     public void printDetails() {
         System.out.println("\tBook Name: " + book_name);
         System.out.println("\tBook Author: " + book_author);
         System.out.println("\tCopies available for sale: " + copies_available);
         System.out.println("\tCopies sold : " + copies_sold);


     }



 }

public class Main {

    public static void main(String[] args) {
        //An array listing the books available in my stock for sale, the copies available,
        // copies sold, author and book name
        String[][] books_for_sale = {
                {"Don Quixote", "Miguel de Cervantes", " 1345", "5076"},
                {"A Tale of Two Cities", "Charles Dickens", "789 ", "3459"},
                {"The Lord of the Rings","J.R.R. Tolkien", "784"," 5786"},
                {"The Little Prince","Antoine de Saint-Exupery","2356"," 567"},
                {"The Hobbit","J.R.R. Tolkien","5678","8893"}
        };
        //Menu
        System.out.println("Dkay Bookshop stock management");
        System.out.println("1.View report of your stock");
        System.out.println("2.Exit the program");
        System.out.print("Enter your option: ");
        Scanner sc = new Scanner(System.in);
        int option = sc.nextInt();
        if(option == 1)
        {

            for(int i = 0; i<books_for_sale.length;i++)
            {
                System.out.print(i+1);
                ReportData myObj = new ReportData();
                myObj.setbook_name(books_for_sale[i][0]);
                myObj.set_author(books_for_sale[i][1]);
                myObj.setCopies_available(books_for_sale[i][2]);
                myObj.setCopies_sold(books_for_sale[i][3]);

                myObj.printDetails();
            }
        }
        else if(option == 2)
        {
            System.out.println("Program exited");
        }
        else
        {
            System.out.println("Invalid option please try again");
        }

    }
}
import java.util.ArrayList;
import java.util.Scanner;


class Product {
	private String code;
	private String warranty;
	private float price;
	private int stockLevel;


	public Product(String code, String warranty, float price, int stockLevel) {
		this.code = code;
		this.warranty = warranty;
		this.price = price;
		this.stockLevel = stockLevel;
	}


	public String toString() {
		return "Code: " + code + "\n" + "Warranty: " + warranty + "\n" + "Price: " + price + "\n" + "Stock level: "
				+ stockLevel + "\n";


	}


	/**
	 * @return the warranty
	 */
	public String getWarranty() {
		return warranty;
	}


	/**
	 * @param warranty the warranty to set
	 */
	public void setWarranty(String warranty) {
		this.warranty = warranty;
	}


	/**
	 * @return the price
	 */
	public float getPrice() {
		return price;
	}


	/**
	 * @param price the price to set
	 */
	public void setPrice(float price) {
		this.price = price;
	}


	/**
	 * @return the stockLevel
	 */
	public int getStockLevel() {
		return stockLevel;
	}


	/**
	 * @param stockLevel the stockLevel to set
	 */
	public void setStockLevel(int stockLevel) {
		this.stockLevel = stockLevel;
	}


	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}


	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
}


public class Main {


	private static Scanner keyboard = new Scanner(System.in);
	private static ArrayList<Product> products = new ArrayList<Product>();


	public static void main(String[] args) {


		int choice = -1;


		while (choice != 5) {
			choice = DisplayMenu();
			keyboard.nextLine();
			if (choice == 1) {
				SaveProduct();
			} else if (choice == 2) {
				UpdateProduct();
			} else if (choice == 3) {
				DeleteProduct();
			} else if (choice == 4) {
				CaptureProduct();
			} else if (choice == 5) {
				ExitApplication();
			} else {
				System.out.println("Wrong menu item.");
			}
		}
		keyboard.close();


	}


	private static int SearchProduct(String code) {
		for (int i = 0; i < products.size(); i++) {
			if (products.get(i).getCode().compareTo(code) == 0) {
				return i;
			}
		}
		return -1;
	}


	private static void SaveProduct() {
		String code;
		String warranty;
		float price;
		int stockLevel;
		System.out.print("Enter code: ");
		code = keyboard.nextLine();
		System.out.print("Enter warranty: ");
		warranty = keyboard.nextLine();
		System.out.print("Enter price: ");
		price = keyboard.nextFloat();
		System.out.print("Enter stock level: ");
		stockLevel = keyboard.nextInt();
		products.add(new Product(code, warranty, price, stockLevel));
	}


	private static void UpdateProduct() {


		String code;
		String warranty;
		float price;
		int stockLevel;
		int ch = -1;
		while (ch != 4) {
			System.out.println("1. Update the product warranty.");
			System.out.println("2. Update the product price.");
			System.out.println("3. Update the product stock level");
			System.out.println("4. Exit to main menu");
			System.out.print("Your choice: ");
			ch = keyboard.nextInt();
			keyboard.nextLine();
			if (ch == 1) {
				System.out.print("Enter code to update: ");
				code = keyboard.nextLine();
				int index = SearchProduct(code);
				if (index != -1) {
					System.out.print("Enter a new warranty: ");
					warranty = keyboard.nextLine();
					products.get(index).setWarranty(warranty);
				} else {
					System.out.println("Wrong code.");
				}
			} else if (ch == 2) {
				System.out.print("Enter code to update: ");
				code = keyboard.nextLine();
				int index = SearchProduct(code);
				if (index != -1) {
					System.out.print("Enter price: ");
					price = keyboard.nextFloat();
					products.get(index).setPrice(price);
				} else {
					System.out.println("Wrong code.");
				}
			} else if (ch == 3) {
				System.out.print("Enter code to update: ");
				code = keyboard.nextLine();
				int index = SearchProduct(code);
				if (index != -1) {
					System.out.print("Enter stock level: ");
					stockLevel = keyboard.nextInt();
					products.get(index).setStockLevel(stockLevel);
				} else {
					System.out.println("Wrong code.");
				}
			}
		}
	}


	private static void DeleteProduct() {
		System.out.print("Enter the product code to be deleted: ");
		String code = keyboard.nextLine();
		int index = SearchProduct(code);
		if (index != -1) {
			String answer = "";
			while (answer.compareToIgnoreCase("y") != 0 && answer.compareToIgnoreCase("n") != 0) {
				System.out.print("Are you sure you want to delete the product? y/n: ");
				answer = keyboard.nextLine();
			}
			if (answer.compareToIgnoreCase("y") == 0) {
				products.remove(index);
				System.out.println("\nThe product has been deleted.\n");
			}
		} else {
			System.out.println("Wrong code.");
		}
	}


	private static int DisplayMenu() {
		System.out.println("1. Save a product.");
		System.out.println("2. Update the product.");
		System.out.println("3. Delete the product.");
		System.out.println("4. Display all products");
		System.out.println("5. Exit");
		System.out.print("Your choice: ");
		return keyboard.nextInt();
	}


	private static void CaptureProduct() {
		for (int i = 0; i < products.size(); i++) {
			System.out.println(products.get(i).toString());
		}
	}


	private static void ExitApplication() {
		System.out.println("Good bye");
	}
}

